﻿using UnityEngine;

public class CursorScript : MonoBehaviour
{
    public void Destroy()
    {
        Destroy(gameObject);
    }
}
